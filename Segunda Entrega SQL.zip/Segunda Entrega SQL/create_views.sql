CREATE VIEW MoviesByGenre AS
SELECT m.title, g.nombre AS genre
FROM Movies m
JOIN Genres g ON m.genre_id = g.id_genero;

CREATE VIEW TopRatedMovies AS
SELECT m.title, AVG(r.rating) AS avg_rating
FROM Movies m
JOIN Ratings r ON m.id_movie = r.movie_id
GROUP BY m.title
HAVING avg_rating > 4;

CREATE VIEW MoviesWithDirectors AS
SELECT m.title, d.nombre AS director
FROM Movies m
JOIN Directors d ON m.director_id = d.id_director;

CREATE VIEW MoviesWithActors AS
SELECT m.title, a.nombre AS actor
FROM Movies m
JOIN Movie_Actor_Relationship mar ON m.id_movie = mar.movie_id
JOIN Actors a ON mar.actor_id = a.id_actor;
