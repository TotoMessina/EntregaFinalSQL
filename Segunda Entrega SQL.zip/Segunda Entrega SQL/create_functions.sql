DELIMITER //

CREATE FUNCTION GetMovieRating(movie_id INT) RETURNS DECIMAL(3, 2)
BEGIN
    DECLARE avg_rating DECIMAL(3, 2);
    SELECT AVG(rating) INTO avg_rating FROM Ratings WHERE movie_id = movie_id;
    RETURN avg_rating;
END //

CREATE FUNCTION GetDirectorName(director_id INT) RETURNS VARCHAR(255)
BEGIN
    DECLARE director_name VARCHAR(255);
    SELECT nombre INTO director_name FROM Directors WHERE id_director = director_id;
    RETURN director_name;
END //

CREATE FUNCTION CalculateMovieDuration(movie_id INT) RETURNS INT
BEGIN
    DECLARE duration INT;
    SELECT duration INTO duration FROM Movies WHERE id_movie = movie_id;
    RETURN duration;
END //

DELIMITER ;
