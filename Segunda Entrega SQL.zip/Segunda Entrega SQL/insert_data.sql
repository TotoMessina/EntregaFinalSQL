INSERT INTO Genres (nombre) VALUES ('Action');
INSERT INTO Genres (nombre) VALUES ('Comedy');
INSERT INTO Genres (nombre) VALUES ('Drama');
INSERT INTO Genres (nombre) VALUES ('Horror');
INSERT INTO Genres (nombre) VALUES ('Sci-Fi');

INSERT INTO Directors (nombre) VALUES ('Steven Spielberg');
INSERT INTO Directors (nombre) VALUES ('Christopher Nolan');
INSERT INTO Directors (nombre) VALUES ('Quentin Tarantino');
INSERT INTO Directors (nombre) VALUES ('Martin Scorsese');
INSERT INTO Directors (nombre) VALUES ('James Cameron');

INSERT INTO Actors (nombre) VALUES ('Leonardo DiCaprio');
INSERT INTO Actors (nombre) VALUES ('Tom Hanks');
INSERT INTO Actors (nombre) VALUES ('Scarlett Johansson');
INSERT INTO Actors (nombre) VALUES ('Brad Pitt');
INSERT INTO Actors (nombre) VALUES ('Meryl Streep');

INSERT INTO Movies (title, release_year, genre_id, director_id, duration) 
VALUES ('Inception', 2010, 5, 2, 148);

INSERT INTO Movies (title, release_year, genre_id, director_id, duration) 
VALUES ('Pulp Fiction', 1994, 1, 3, 154);

INSERT INTO Movies (title, release_year, genre_id, director_id, duration) 
VALUES ('The Wolf of Wall Street', 2013, 3, 4, 180);

INSERT INTO Movies (title, release_year, genre_id, director_id, duration) 
VALUES ('Titanic', 1997, 3, 5, 195);

INSERT INTO Movies (title, release_year, genre_id, director_id, duration) 
VALUES ('Jurassic Park', 1993, 5, 1, 127);

INSERT INTO Ratings (movie_id, rating) VALUES (1, 4.8);
INSERT INTO Ratings (movie_id, rating) VALUES (2, 4.5);
INSERT INTO Ratings (movie_id, rating) VALUES (3, 4.7);
INSERT INTO Ratings (movie_id, rating) VALUES (4, 4.6);
INSERT INTO Ratings (movie_id, rating) VALUES (5, 4.9);

INSERT INTO Movie_Actor_Relationship (movie_id, actor_id) VALUES (1, 1); -- Inception, Leonardo DiCaprio
INSERT INTO Movie_Actor_Relationship (movie_id, actor_id) VALUES (2, 4); -- Pulp Fiction, Brad Pitt
INSERT INTO Movie_Actor_Relationship (movie_id, actor_id) VALUES (3, 1); -- The Wolf of Wall Street, Leonardo DiCaprio
INSERT INTO Movie_Actor_Relationship (movie_id, actor_id) VALUES (4, 2); -- Titanic, Tom Hanks
INSERT INTO Movie_Actor_Relationship (movie_id, actor_id) VALUES (5, 3); -- Jurassic Park, Scarlett Johansson
