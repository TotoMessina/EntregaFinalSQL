CREATE TABLE Genres (
   id_genero INT PRIMARY KEY AUTO_INCREMENT,
   nombre VARCHAR(50) NOT NULL
);

CREATE TABLE Directors (
   id_director INT PRIMARY KEY AUTO_INCREMENT,
   nombre VARCHAR(255) NOT NULL
);

CREATE TABLE Actors (
   id_actor INT PRIMARY KEY AUTO_INCREMENT,
   nombre VARCHAR(255) NOT NULL
);

CREATE TABLE Movies (
   id_movie INT PRIMARY KEY AUTO_INCREMENT,
   title VARCHAR(255) NOT NULL,
   release_year INT NOT NULL,
   genre_id INT NOT NULL,
   director_id INT NOT NULL,
   duration INT NOT NULL,
   FOREIGN KEY (genre_id) REFERENCES Genres(id_genero),
   FOREIGN KEY (director_id) REFERENCES Directors(id_director)
);

CREATE TABLE Ratings (
   id_rating INT PRIMARY KEY AUTO_INCREMENT,
   movie_id INT NOT NULL,
   rating DECIMAL(3, 2) NOT NULL,
   FOREIGN KEY (movie_id) REFERENCES Movies(id_movie)
);

CREATE TABLE Movie_Actor_Relationship (
   movie_id INT NOT NULL,
   actor_id INT NOT NULL,
   PRIMARY KEY (movie_id, actor_id),
   FOREIGN KEY (movie_id) REFERENCES Movies(id_movie),
   FOREIGN KEY (actor_id) REFERENCES Actors(id_actor)
);
