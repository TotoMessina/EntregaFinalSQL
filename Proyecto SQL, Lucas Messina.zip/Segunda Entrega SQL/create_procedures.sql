DELIMITER //

CREATE PROCEDURE AddNewMovie(IN title VARCHAR(255), IN release_year INT, IN genre_id INT, IN director_id INT)
BEGIN
    INSERT INTO Movies (title, release_year, genre_id, director_id) 
    VALUES (title, release_year, genre_id, director_id);
END //

CREATE PROCEDURE UpdateMovieRating(IN movie_id INT, IN new_rating DECIMAL(3,2))
BEGIN
    UPDATE Ratings SET rating = new_rating WHERE movie_id = movie_id;
END //

CREATE PROCEDURE DeleteOldMovies()
BEGIN
    DELETE FROM Movies WHERE release_year < YEAR(CURDATE()) - 5;
END //

DELIMITER ;
