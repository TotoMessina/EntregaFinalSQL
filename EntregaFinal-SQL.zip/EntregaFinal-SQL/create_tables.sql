CREATE TABLE Genre (
    id_genre INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL
);

CREATE TABLE Director (
    id_director INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL
);

CREATE TABLE Actor (
    id_actor INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL
);

CREATE TABLE Movie (
    id_movie INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    release_year INT NOT NULL,
    genre_id INT NOT NULL,
    director_id INT NOT NULL,
    duration INT NOT NULL,
    average_rating DECIMAL(3, 2),
    FOREIGN KEY (genre_id) REFERENCES Genre(id_genre),
    FOREIGN KEY (director_id) REFERENCES Director(id_director)
);

CREATE TABLE Rating (
    id_rating INT PRIMARY KEY AUTO_INCREMENT,
    movie_id INT NOT NULL,
    rating DECIMAL(3, 2) NOT NULL,
    FOREIGN KEY (movie_id) REFERENCES Movie(id_movie)
);

CREATE TABLE MovieActor (
    movie_id INT NOT NULL,
    actor_id INT NOT NULL,
    PRIMARY KEY (movie_id, actor_id),
    FOREIGN KEY (movie_id) REFERENCES Movie(id_movie),
    FOREIGN KEY (actor_id) REFERENCES Actor(id_actor)
);

CREATE TABLE User (
    id_user INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE Review (
    id_review INT PRIMARY KEY AUTO_INCREMENT,
    movie_id INT NOT NULL,
    user_id INT NOT NULL,
    review_text TEXT,
    FOREIGN KEY (movie_id) REFERENCES Movie(id_movie),
    FOREIGN KEY (user_id) REFERENCES User(id_user)
);

CREATE TABLE Country (
    id_country INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL
);

CREATE TABLE City (
    id_city INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    country_id INT,
    FOREIGN KEY (country_id) REFERENCES Country(id_country)
);

CREATE TABLE MovieAwards (
    id_award INT PRIMARY KEY AUTO_INCREMENT,
    movie_id INT NOT NULL,
    award_name VARCHAR(255) NOT NULL,
    award_year INT,
    FOREIGN KEY (movie_id) REFERENCES Movie(id_movie)
);

CREATE TABLE UserActivity (
    id_activity INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    movie_id INT NOT NULL,
    activity_date DATE,
    FOREIGN KEY (user_id) REFERENCES User(id_user),
    FOREIGN KEY (movie_id) REFERENCES Movie(id_movie)
);

CREATE TABLE SubscriptionPlan (
    id_plan INT PRIMARY KEY AUTO_INCREMENT,
    plan_name VARCHAR(255) NOT NULL,
    monthly_cost DECIMAL(5, 2) NOT NULL
);

CREATE TABLE Subscription (
    id_subscription INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    plan_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    FOREIGN KEY (user_id) REFERENCES User(id_user),
    FOREIGN KEY (plan_id) REFERENCES SubscriptionPlan(id_plan)
);

CREATE TABLE Payment (
    id_payment INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_date DATE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES User(id_user)
);
