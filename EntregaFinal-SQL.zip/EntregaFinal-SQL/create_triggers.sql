DELIMITER //

CREATE TRIGGER after_rating_insert 
AFTER INSERT ON Rating
FOR EACH ROW
BEGIN
    UPDATE Movie
    SET average_rating = (SELECT AVG(rating) FROM Rating WHERE movie_id = NEW.movie_id)
    WHERE id_movie = NEW.movie_id;
END //

CREATE TRIGGER after_rating_update 
AFTER UPDATE ON Rating
FOR EACH ROW
BEGIN
    UPDATE Movie
    SET average_rating = (SELECT AVG(rating) FROM Rating WHERE movie_id = NEW.movie_id)
    WHERE id_movie = NEW.movie_id;
END //

CREATE TRIGGER before_movie_delete 
BEFORE DELETE ON Movie
FOR EACH ROW
BEGIN
    DELETE FROM MovieActor WHERE movie_id = OLD.id_movie;
END //

CREATE TRIGGER before_user_delete 
BEFORE DELETE ON User
FOR EACH ROW
BEGIN
    DELETE FROM UserActivity WHERE user_id = OLD.id_user;
END //

DELIMITER ;
