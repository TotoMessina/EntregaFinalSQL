INSERT INTO Genre (name) VALUES ('Action');
INSERT INTO Genre (name) VALUES ('Comedy');
INSERT INTO Genre (name) VALUES ('Drama');
INSERT INTO Genre (name) VALUES ('Horror');
INSERT INTO Genre (name) VALUES ('Sci-Fi');

INSERT INTO Director (name) VALUES ('Steven Spielberg');
INSERT INTO Director (name) VALUES ('Christopher Nolan');
INSERT INTO Director (name) VALUES ('Quentin Tarantino');
INSERT INTO Director (name) VALUES ('Martin Scorsese');
INSERT INTO Director (name) VALUES ('James Cameron');

INSERT INTO Actor (name) VALUES ('Leonardo DiCaprio');
INSERT INTO Actor (name) VALUES ('Tom Hanks');
INSERT INTO Actor (name) VALUES ('Scarlett Johansson');
INSERT INTO Actor (name) VALUES ('Brad Pitt');
INSERT INTO Actor (name) VALUES ('Meryl Streep');

INSERT INTO Movie (title, release_year, genre_id, director_id, duration) 
VALUES ('Inception', 2010, 5, 2, 148);

INSERT INTO Movie (title, release_year, genre_id, director_id, duration) 
VALUES ('Pulp Fiction', 1994, 1, 3, 154);

INSERT INTO Movie (title, release_year, genre_id, director_id, duration) 
VALUES ('The Wolf of Wall Street', 2013, 3, 4, 180);

INSERT INTO Movie (title, release_year, genre_id, director_id, duration) 
VALUES ('Titanic', 1997, 3, 5, 195);

INSERT INTO Movie (title, release_year, genre_id, director_id, duration) 
VALUES ('Jurassic Park', 1993, 5, 1, 127);

INSERT INTO Rating (movie_id, rating) VALUES (1, 4.8);
INSERT INTO Rating (movie_id, rating) VALUES (2, 4.5);
INSERT INTO Rating (movie_id, rating) VALUES (3, 4.7);
INSERT INTO Rating (movie_id, rating) VALUES (4, 4.6);
INSERT INTO Rating (movie_id, rating) VALUES (5, 4.9);

INSERT INTO MovieActor (movie_id, actor_id) VALUES (1, 1); -- Inception, Leonardo DiCaprio
INSERT INTO MovieActor (movie_id, actor_id) VALUES (2, 4); -- Pulp Fiction, Brad Pitt
INSERT INTO MovieActor (movie_id, actor_id) VALUES (3, 1); -- The Wolf of Wall Street, Leonardo DiCaprio
INSERT INTO MovieActor (movie_id, actor_id) VALUES (4, 2); -- Titanic, Tom Hanks
INSERT INTO MovieActor (movie_id, actor_id) VALUES (5, 3); -- Jurassic Park, Scarlett Johansson
