CREATE VIEW MovieDetails AS
SELECT 
    Movie.title,
    Movie.release_year,
    Genre.name AS genre_name,
    Director.name AS director_name,
    Movie.duration,
    Movie.average_rating
FROM 
    Movie
JOIN 
    Genre ON Movie.genre_id = Genre.id_genre
JOIN 
    Director ON Movie.director_id = Director.id_director;

CREATE VIEW TopRatedMovies AS
SELECT 
    title,
    average_rating
FROM 
    Movie
WHERE 
    average_rating IS NOT NULL
ORDER BY 
    average_rating DESC
LIMIT 10;

CREATE VIEW RecentMovies AS
SELECT 
    title,
    release_year
FROM 
    Movie
ORDER BY 
    release_year DESC
LIMIT 10;

CREATE VIEW DirectorActivity AS
SELECT 
    Director.name AS director_name,
    COUNT(Movie.id_movie) AS movie_count
FROM 
    Director
JOIN 
    Movie ON Director.id_director = Movie.director_id
GROUP BY 
    Director.name;

CREATE VIEW UserMovieInteraction AS
SELECT 
    User.username,
    Movie.title,
    UserActivity.activity_date
FROM 
    UserActivity
JOIN 
    User ON UserActivity.user_id = User.id_user
JOIN 
    Movie ON UserActivity.movie_id = Movie.id_movie;
