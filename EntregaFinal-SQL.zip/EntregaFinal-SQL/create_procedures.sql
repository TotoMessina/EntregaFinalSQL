DELIMITER //

CREATE PROCEDURE AddRating(IN movieID INT, IN ratingValue DECIMAL(3,2))
BEGIN
    INSERT INTO Rating (movie_id, rating) VALUES (movieID, ratingValue);
    UPDATE Movie SET average_rating = (SELECT AVG(rating) FROM Rating WHERE movie_id = movieID) WHERE id_movie = movieID;
END //

CREATE PROCEDURE AddUser(IN username VARCHAR(255), IN email VARCHAR(255))
BEGIN
    INSERT INTO User (username, email) VALUES (username, email);
END //

CREATE PROCEDURE AddReview(IN movieID INT, IN userID INT, IN reviewText TEXT)
BEGIN
    INSERT INTO Review (movie_id, user_id, review_text) VALUES (movieID, userID, reviewText);
END //

DELIMITER ;
