DELIMITER //

CREATE FUNCTION GetMovieRating(movieID INT) RETURNS DECIMAL(3,2)
BEGIN
    DECLARE avgRating DECIMAL(3,2);
    SELECT AVG(rating) INTO avgRating FROM Rating WHERE movie_id = movieID;
    RETURN avgRating;
END //

CREATE FUNCTION GetMovieGenre(movieID INT) RETURNS VARCHAR(50)
BEGIN
    DECLARE genreName VARCHAR(50);
    SELECT Genre.name INTO genreName
    FROM Movie
    JOIN Genre ON Movie.genre_id = Genre.id_genre
    WHERE Movie.id_movie = movieID;
    RETURN genreName;
END //

DELIMITER ;
